
// This is a nodejs server side app. But we taking advantage of these express features
// This should return data for client req and responses

const path = require('path');
const express = require('express'); //Import express
const bodyParser = require('body-parser');
const mongoose = require('mongoose');

const postsRoutes = require('./routes/posts');
const userRoutes = require('./routes/user');

const app = express(); // create express app. This will act like a middleware to pass req and responses

//connect to the mongodb database via mongoose
mongoose.connect('mongodb://localhost/node-angular',  { useNewUrlParser: true, useUnifiedTopology: true })
.then(() => {
    console.log('Connection established with MongoDB successfully!');
})
.catch(() => {
    console.log('Connection failed!');
});

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: false})); //extended false to support default features in the url encodeing
app.use('/images', express.static(path.join('images')));  //Allows accessing image folder for services that having image 

app.use((req, res, next) => {
    res.setHeader('Access-Control-Allow-Origin', "*"); //Allow accesing of all domains
    res.setHeader(
    'Access-Control-Allow-Headers',
    "Origin, X-Requested-With, Content-Type, Accept, Authorization"); //Allow req with these headers type
    res.setHeader('Access-Control-Allow-Methods', "GET, POST, PUT, PATCH, DELETE, OPTIONS"); //OPTIONS typically exist in browser
    next();
});

app.use('/post', postsRoutes);
app.use('/authentication', userRoutes);


// Need to wire up server.js and express for active listening.
// Express is a listener for incoming requests
module.exports = app; 
