// this file will be called before actual REST api calls
const jwt = require('jsonwebtoken');

//middleware - its just a function which execited for every incoming requests
module.exports = (req, res, next) => {
    try {
        const token = req.headers.authorization.split(" ")[1]; //get only te token if its in format 'Bearer jjjbjvj'
        // process.env.JWT_KEY - these global variables injected into running node process
        const decodedToken = jwt.verify(token, process.env.JWT_KEY); //verfying te token with te same secret key tat we used to create yoken
        //This middleware can add token details as a req params in every reqs
        req.userData = {email: decodedToken.email, userId: decodedToken.userId};
        next(); //will continiue wit route files
    }
    catch(error) {
        res.status(401).json({message: 'You are not authenticated!'});
    }
}