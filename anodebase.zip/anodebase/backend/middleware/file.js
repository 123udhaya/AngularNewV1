const multer = require('multer');

//Multer configuration
const MIME_TYPE_MAP = {
    'image/png': 'png',
    'image/jpeg': 'jpg',
    'image/jpg': 'jpg'
};

const storage = multer.diskStorage({
//Destination will be called whenever multer tries to save a file
destination: (req, file, cb) => {
    const isValid = MIME_TYPE_MAP[file.mimetype];
    let error = new Error('Invalid mime type');
    if(isValid) {
        error = null;
    }
    cb(error, "images"); //Path where image should be stored. This path should be relative to server.js file
},
filename: (req, file, cb) => {
    const name = file.originalname.toLowerCase().split(' ').join('-');
    const ext = MIME_TYPE_MAP[file.mimetype];
    cb(null, name + '-' + Date.now() + '.' + ext); //unique file naming
}
});

module.exports = multer({storage: storage}).single('image');