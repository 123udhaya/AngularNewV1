const mongoose = require('mongoose');

// schema defenition
const postSchema = mongoose.Schema({
    title: {type: String, require: true},
    content: {type: String, require: true},
    imagePath: {type: String, require: true},
    creator: {type: mongoose.Schema.Types.ObjectId, ref: 'User', require: true}
});

//convert schema defenition to model
module.exports = mongoose.model('Post', postSchema); //plural form of the model name will be a collection(table name)