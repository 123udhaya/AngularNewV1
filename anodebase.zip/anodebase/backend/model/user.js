const mongoose = require('mongoose');
const uniqueValidator = require('mongoose-unique-validator'); //its a plugin. will check the data before we save it into the database

// schema defenition
const authSchema = mongoose.Schema({
    email: {type: String, require: true, unique: true},
    password: {type: String, require: true}
});

authSchema.plugin(uniqueValidator);

//convert schema defenition to model
module.exports = mongoose.model('User', authSchema); //plural form of the model name will be a collection(table name)