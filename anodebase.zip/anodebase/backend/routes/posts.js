const express = require('express');
const router = express.Router();
const postController = require('../controllers/posts');
const checkAuth = require('../middleware/check-auth'); //add this middleware in all calls to verify all req. Add tis after api call paths and before te act impl api logics
const extractFile = require('../middleware/file');

//Post method will contain reqs sent by client. To extract that req data, we insatll body-parser package
//multer(storage).single('image') - multer will try to extract a single file from the incoming request
router.post('/api/addPost', checkAuth, extractFile, postController.createPost);

router.get('/api/getPosts', checkAuth, postController.fetchPosts);

router.delete('/api/deletePost/:id', checkAuth, postController.deletePost);

router.put('/api/updatePost/:id', checkAuth, extractFile, postController.updatePost);

router.get('/api/getPostbyId/:id', postController.fetchPost);

module.exports = router;
