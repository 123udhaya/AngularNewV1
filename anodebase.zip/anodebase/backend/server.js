//Create a nodejs new server and run it by - node server.js
//For every change we need to quit running nodejs server and restart it. so we can use nodemon

const http = require('http'); //Import syntax, httpp can be used to create nodejs server
const app = require('./app');
const debug = require("debug")("node-angular");

// Ensure the port number we are getting from env is valid number
const normalizePort = val => {
    var port = parseInt(val, 10);
    if(isNaN(port)) {
        return val;
    }

    if(port >= 0) {
        return port;
    }

    return false;
};

//Simply check which type of err occured and logs the err and exit from nodejs server
const onError = error => {
    if(error.syscall !== 'listen') {
        throw error;
    }
    const bind = typeof addr === 'string' ? "pipe " + addr : "port " + port;
    switch(error.code) {
        case "EACCESS":
            console.error(bind + " requires elevated privileges");
            process.exit(1);
            break;
        case "EADDRINUSE":
            console.error(bind + " is already in use");
            process.exit(1);
            break;
        default:
            throw error;
    }
};

const onListening = () => {
    const addr = server.address();
    const bind = typeof addr === 'string' ? "pipe " + addr : "port " + port;
    debug("Listening on " + bind);
};

const port = normalizePort(process.env.PORT || 3000);
app.set('port', port);

//Handle req and responses
// const server = http.createServer((req, res) => {
//     res.end('This is my first response');
// });
//we need to add lot of logic to send and extract the received data. Thats y we need Express backend
const server = http.createServer(app);
server.on("error", onError);
server.on("Listening", onListening);


//Activate Server
server.listen(port);