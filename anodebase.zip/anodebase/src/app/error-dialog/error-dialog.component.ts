import { Component, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material';

@Component({
  selector: 'app-error-dialog',
  templateUrl: './error-dialog.component.html',
  styleUrls: ['./error-dialog.component.css']
})
export class ErrorDialogComponent implements OnInit {

  //@Inject allows to specify a special token and that will just be important for the dependency injection to identify the data we passes
  //special way of inject required due to special way of error interceptio created with
  constructor(@Inject(MAT_DIALOG_DATA) public data: {message: string}) { }
  // constructor() { }

  ngOnInit(): void {
  }

}
