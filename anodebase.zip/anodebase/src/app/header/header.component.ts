import { Component, OnInit, OnDestroy } from '@angular/core';
import { AuthService } from '../shared/services/auth.service';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit, OnDestroy {
  private unSubscribe$ = new Subject();
  userAutenticated = false;
  constructor(private authService: AuthService) { }

  ngOnInit(): void {
    this.userAutenticated = this.authService.getIsAuth();
    this.authService.getAuthStatusListener();
    this.authService.authStatusListenerObservable.pipe(takeUntil(this.unSubscribe$))
    .subscribe(isAutenticated => {
      this.userAutenticated = isAutenticated;
    });
  }

  onLogout() {
    this.authService.onLogout();
  }

  ngOnDestroy(): void {
    this.unSubscribe$.next();
    this.unSubscribe$.complete();
  }
}
