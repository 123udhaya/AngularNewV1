import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { Post } from 'src/app/shared/models/post.model';
import { PostService } from '../../shared/services/posts.service';
import { Actions } from '../../shared/enum/enum-helper';
import { mimeType } from '../../shared/validators/mimetype.validator';

@Component({
  selector: 'app-post-create',
  templateUrl: './post-create.component.html',
  styleUrls: ['./post-create.component.css']
})
export class PostCreateComponent implements OnInit {

  private mode = Actions.create;
  private postId: string;
  post: Post;
  form: FormGroup;
  imagePreview: string;
  constructor(private postService: PostService, private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.form = new FormGroup({
      title: new FormControl(null, [Validators.required, Validators.minLength(3)]),
      content: new FormControl(null, Validators.required),
      image: new FormControl(null, {validators: [Validators.required], asyncValidators: [mimeType] })
    });
    this.route.paramMap.subscribe((params) => {
      if(params.has('postId')) {
        this.mode = Actions.edit;
        this.postId = params.get('postId');
        this.postService.getPost(this.postId).subscribe((post) => {
          this.post = {id: post._id, title: post.title, content: post.content, imagePath: post.imagePath, creator: post.creator};
          this.form.setValue({title: this.post.title, content: this.post.content, image: this.post.imagePath})
        });
      } else {
        this.mode = Actions.create;
        this.postId = null;
      }
    });
  }

  onImagePicked(event: Event) {
    const file = (event.target as HTMLInputElement).files[0];
    this.form.patchValue({image: file});
    this.form.get('image').updateValueAndValidity();
    const reader = new FileReader();
    reader.onload = () => {
      this.imagePreview = reader.result as string;
    }
    reader.readAsDataURL(file);
  }

  onSavePost() {
    if(this.form.valid) {
    if(this.mode === Actions.create) {
      this.postService.addPost(this.form.value.title, this.form.value.content, this.form.value.image);
    } else {
      const reqObj: Post = {
        id: this.postId,
        title: this.form.value.title,
        content: this.form.value.content,
        imagePath: this.form.value.image,
        creator: null
      };
      this.postService.updatePost(reqObj);
    }
    this.form.reset();
    }
  }

}
