import { Component, OnInit, OnDestroy } from '@angular/core';
import { Post } from '../../shared/models/post.model';
import { PostService } from '../../shared/services/posts.service';
import { take, takeUntil } from 'rxjs/operators';
import { Subject } from 'rxjs';
import { PageEvent } from '@angular/material';
import { AuthService } from '../../shared/services/auth.service';

@Component({
  selector: 'app-post-list',
  templateUrl: './post-list.component.html',
  styleUrls: ['./post-list.component.css']
})
export class PostListComponent implements OnInit, OnDestroy {

  posts: Post[] = [];
  totalPosts = 0;
  recordsPerPage = 2;
  pageSizeOption = [2,4,6];
  currentPage = 1;
  userAutenticated = false;
  userId: string;
  private unSubscribe$ = new Subject();
  
  constructor(private postService: PostService, private authService: AuthService) { }

  ngOnInit(): void {
    this.userId = this.authService.getUserId();
    this.postService.getPosts(this.recordsPerPage, this.currentPage);
    this.postService.postsUpdatedObservable.pipe(takeUntil(this.unSubscribe$))
    .subscribe((postData: {post: Post[], postCount: number}) => {
      this.posts = postData.post;
      this.totalPosts = postData.postCount;
    })
    this.userAutenticated = this.authService.getIsAuth();
    this.authService.getAuthStatusListener();
    this.authService.authStatusListenerObservable.pipe(takeUntil(this.unSubscribe$))
    .subscribe(isAutenticated => {
      console.log('isAutenticated', isAutenticated);
      this.userId = this.authService.getUserId();
      this.userAutenticated = isAutenticated;
    });
  }

  OnDelete(postId: string) {
    this.postService.deletePost(postId).subscribe(() => {
      this.postService.getPosts(this.recordsPerPage, this.currentPage);
    });
  }

  onPageChange(pageData: PageEvent) {
    this.currentPage = pageData.pageIndex + 1;
    this.recordsPerPage = pageData.pageSize;
    this.postService.getPosts(this.recordsPerPage, this.currentPage);
  }

  ngOnDestroy() {
    this.unSubscribe$.next();
    this.unSubscribe$.complete();
  }

}
