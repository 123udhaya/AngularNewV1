
enum Actions {
    create,
    edit
}

export { Actions };