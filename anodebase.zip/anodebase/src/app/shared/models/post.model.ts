
interface Post {
    id: string;
    title: string;
    content: string;
    imagePath: File | string;
    creator: String;
}

interface PostServer {
    _id: string;
    title: string;
    content: string;
    imagePath: string;
    creator: String;
}

export {Post, PostServer};