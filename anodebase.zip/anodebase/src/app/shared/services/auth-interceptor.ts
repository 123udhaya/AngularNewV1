import { HttpInterceptor, HttpRequest, HttpHandler } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { AuthService } from './auth.service';

// services wic needs to use other injectable services has to have @Injectable annotation.
// We need to add it in our angular app by providing or injecting this service..app.module.ts
@Injectable()
//HttpInterceptor interface given by angular. it will be caaled before every outgoing reqs
export class AuthInterceptor implements HttpInterceptor{
    constructor(private authService: AuthService) {}

    //This class as to ave intercept method because Angular will call this method for requests leaving your app.
    // next - allows the app apis to get interceptor reqs and res.To continue te journey trougout the app 
    intercept(req: HttpRequest<any>, next: HttpHandler) {
        const authToken = this.authService.getToken();
        const authRequest = req.clone({ //Clone will contain the copy of the request
            headers: req.headers.set('Authorization', "Bearer " + authToken) // set means not overriding existing headers. Its just ass a new one into te  hader
        });
        
        return next.handle(authRequest); //Here we actually allow te reqs to continue its journey
    }
}
