import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Router } from "@angular/router";
import { AuthUser } from '../models/auth.model';
import { Subject } from 'rxjs';
import { ServicesGlobal } from '../services/services.global';

@Injectable({
    providedIn: "root"
})

export class AuthService {
    private token: string;
    private isAuthenticated = false;
    private userId: string;
    private tokenTomer: any; //available in typescript
    private authStatusListener = new Subject<boolean>();
    authStatusListenerObservable = this.authStatusListener.asObservable();
    constructor(private http: HttpClient, private route: Router) {}

    getToken() {
        return this.token;
    }

    getAuthStatusListener() {
        this.authStatusListener.asObservable();
    }

    getIsAuth() {
        return this.isAuthenticated;
    }

    getUserId() {
        return this.userId;
    }

    createUser(email: string, pass: string) {
        const autData: AuthUser = {email: email, password: pass};
        this.http.post(ServicesGlobal.CREATE_USER, autData)
        .subscribe(response => {
            this.route.navigate(['/']);
        })
    }

    login(email: string, pass: string) {
        const autData: AuthUser = {email: email, password: pass};
        this.http.post<{token: string, expiresIn: number, userId: string}>(ServicesGlobal.USER_LOGIN, autData)
        .subscribe(response => {
            const token = response.token;
            this.token = token;
            if (token) {
                const expiresInDuration = response.expiresIn;
                this.setAuthTimer(expiresInDuration);
                this.isAuthenticated = true;
                this.userId = response.userId;
                this.authStatusListener.next(true);
                const expirationDate = new Date(new Date().getTime() + expiresInDuration * 1000);
                this.setAuthData(token, expirationDate, this.userId);
                this.route.navigate(['/']);
            }
        });
    }

    autoAuthUser() {
        const autInformation = this.getAuthData();
        console.log('autInformation', autInformation);
        if(!autInformation) {
            return;
        }
        const expiresIn = autInformation.expirationDate.getTime() - new Date().getTime();
        if (expiresIn > 0) {
            this.token = autInformation.token;
            this.isAuthenticated = true;
            this.userId = autInformation.userId;
            this.setAuthTimer(expiresIn / 1000);
            this.authStatusListener.next(true);
        }
    }

    onLogout() {
        this.token = null;
        this.isAuthenticated = false;
        this.authStatusListener.next(false);
        clearTimeout(this.tokenTomer);
        this.clearAuthData();
        this.userId = null;
        this.route.navigate(['/auth/login']);
    }

    private setAuthTimer(duration: number) {
        this.tokenTomer = setTimeout(() => {
            this.onLogout();
        }, duration * 1000);
    }

    private setAuthData(token: string, expirationDate: Date, userId: string) {
        localStorage.setItem("token", token);
        localStorage.setItem("expiration", expirationDate.toISOString());
        localStorage.setItem("userId", userId);
    }

    private clearAuthData() {
        localStorage.removeItem("token");
        localStorage.removeItem("expiration");
        localStorage.removeItem("userId");
    }

    private getAuthData() {
        const token = localStorage.getItem('token');
        const expirationDate = localStorage.getItem('expiration');
        const userId = localStorage.getItem('userId');
        if( !token || !expirationDate) {
            return;
        }
        return {
            token: token,
            expirationDate: new Date(expirationDate),
            userId: userId
        };
    }
}