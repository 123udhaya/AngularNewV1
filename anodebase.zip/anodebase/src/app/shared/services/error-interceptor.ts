import  { HttpInterceptor, HttpRequest, HttpHandler, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { MatDialog, MatDialogConfig } from '@angular/material';
import { throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { ErrorDialogComponent } from '../../error-dialog/error-dialog.component';

//We will use Injectable whenever we use service
@Injectable()

export class ErrorInterceptor implements HttpInterceptor {
    
    constructor(private dialog: MatDialog) {}
    intercept(req: HttpRequest<any>, next: HttpHandler) {
        return next.handle(req) //handle gives us response observable stream
        .pipe(
            catchError((error: HttpErrorResponse) => {
                let errorMessage = 'An unknown error occured!';
                if(error.error.message) {
                    errorMessage = error.error.message;
                }
                const dialogConfig = new MatDialogConfig();
                // this.dialog.open(ErrorDialogComponent, {data: {message: errorMessage}});
                // this.dialog.open(ErrorDialogComponent,  {
                //     height: '400px',
                //     width: '600px',
                //   });
                alert(errorMessage);
                return throwError(error);
            })
        )
    }
}