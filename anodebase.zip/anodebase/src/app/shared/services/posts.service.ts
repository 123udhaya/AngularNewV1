import { Injectable } from "@angular/core";
import { Post, PostServer } from '../models/post.model';
import { Subject }from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { map } from "rxjs/operators";
import { Router } from '@angular/router';
import { ServicesGlobal } from '../services/services.global';

@Injectable({providedIn: 'root'})
export class PostService {
    private posts: Post[] = [];
    private postsUpdated = new Subject<{post: Post[], postCount: number}>();
    postsUpdatedObservable = this.postsUpdated.asObservable();

    constructor(private http: HttpClient, private route: Router) {}

    getPosts(postsPerPage: number, currentPage: number) {
        const queryParams = `?pagesize=${postsPerPage}&page=${currentPage}`;
        this.http.get<{message: string, posts: any, maxPosts: number}>(ServicesGlobal.GET_POSTS + queryParams)
        .pipe(map((postdata) => {
            return {posts: postdata.posts.map(post => {
                return {
                    title: post.title,
                    content: post.content,
                    id: post._id,
                    imagePath: post.imagePath,
                    creator: post.creator
                }
            }),
             maxPosts: postdata.maxPosts}
        }))
        .subscribe((modifiedPosts) => {
            this.posts = modifiedPosts.posts;
            this.postsUpdated.next({post: [...this.posts], postCount: modifiedPosts.maxPosts});
        });
    }

    addPost(title: string, content: string, image: File) {
        const postData = new FormData(); //this is a data format which allow us to combine both textvalues(json) and blob(file)
        postData.append('title', title);
        postData.append('content', content);
        postData.append('image', image, title);
        this.http.post<{message: string, post: Post}>(ServicesGlobal.CREATE_POST, postData)
        .subscribe((responseData) => {
            this.route.navigate(["/"]);
        });
    }

    deletePost(postsId: string) {
        return this.http.delete(ServicesGlobal.DELETE_POST + postsId);
    }

    getPost(id: string) {
        return this.http.get<PostServer>(ServicesGlobal.GET_POST_BY_ID + id)
    }

    updatePost(updatePost: Post) {
        let postData: Post | FormData;
        if(typeof(updatePost.imagePath) === 'object') {
            postData = new FormData();
            postData.append('id', updatePost.id);
            postData.append('title', updatePost.title);
            postData.append('content', updatePost.content);
            postData.append('image', updatePost.imagePath, updatePost.title);
        } else {
            postData = {id: updatePost.id, title: updatePost.title, content: updatePost.content, imagePath: updatePost.imagePath, creator: updatePost.creator};
        }
        this.http.put(ServicesGlobal.UPDATE_POST + updatePost.id, postData)
        .subscribe(response => {
            this.route.navigate(["/"]);
        });
    }
}