import { environment } from '../../../environments/environment';

export const ServicesGlobal = {
    CREATE_USER: environment.apiAuthUrl + 'api/signup',
    USER_LOGIN: environment.apiAuthUrl + 'api/login',
    GET_POSTS: environment.apiPostUrl + 'api/getPosts',
    CREATE_POST: environment.apiPostUrl + 'api/addPost',
    DELETE_POST: environment.apiPostUrl + 'api/deletePost/',
    GET_POST_BY_ID: environment.apiPostUrl + 'api/getPostbyId/',
    UPDATE_POST: environment.apiPostUrl + 'api/updatePost/'
};